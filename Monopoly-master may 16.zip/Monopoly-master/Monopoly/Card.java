
/**
 * Write a description of class Cards here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Random;
public class Card
{
    public static void CardPickup (Player player, int cardType)
    {

        Random rand = new Random();
        if (cardType ==1)
        {
            int card = rand.nextInt(16);
            switch (card){
                case 0:
                
                break;
                case 1:
                break;
                case 2:
                break;
                case 3:
                break;
                case 4:
                break;
                case 5:
                break;
                case 6:
                break;
                case 7:
                break;
                case 8:
                break;
                case 9:
                break;
                case 10:
                break;
                case 11:
                break;
                case 12:
                break;
                case 13:
                break;
                case 14:
                break;
                case 15:
                break;
            }
        }
        else if (cardType == 2)
        {

        }
    }
}
