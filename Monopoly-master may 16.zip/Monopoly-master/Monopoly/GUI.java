
/**
 * Write a description of class GUI here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GUI
{
   public GUI (Space[] board)
   {
       
   }
}
