
/**
 * Write a description of class Space here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
abstract class Space
{
    public int location;
    public String name;
    
    
    public int getLoc()
    {
        return location;
    }
    
    public String getName()
    {
        return name;
    }
    
}
