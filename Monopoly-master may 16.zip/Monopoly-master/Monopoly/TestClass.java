
/**
 * Write a description of class TestClass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestClass
{
    public static void main (String args[])
    {
        Game MonopolyGame = new MonopolyGame();
    }
}
