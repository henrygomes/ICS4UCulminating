public interface Game
{
    
}